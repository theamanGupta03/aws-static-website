exports.handler = async (event) => {
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message: "Hello from Lambda!",
      path: event.rawPath,
      timestamp: new Date().toISOString()
    })
  };
};
